/*
 * FILE: rdt_sender.cc
 * DESCRIPTION: Reliable data transfer sender.
 * NOTE: This implementation assumes there is no packet loss, corruption, or 
 *       reordering.  You will need to enhance it to deal with all these 
 *       situations.  In this implementation, the packet format is laid out as 
 *       the following:
 *       
 *       |<-  1 byte  ->|<-             the rest            ->|
 *       | payload size |<-             payload             ->|
 *
 *       The first byte of each packet indicates the size of the payload
 *       (excluding this single-byte header)
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <queue>
#include <map>

#include "rdt_struct.h"
#include "rdt_sender.h"

#define window_size 10
#define timeout 0.3

int sequence_number = 1;
int window_left = window_size; // -- when sendToLower, ++ when receive ack
std::queue <struct packet*> unsend_pkts;
std::map <int, bool> unack_pkts;
std::map <int, struct packet*> sliding_window; // save pkts in window

short Sender_CheckSum(struct packet* pkt) 
{
    unsigned long sum = 0;
    for(int i = 2; i < RDT_PKTSIZE; i += 2) sum += *(short *)(&(pkt->data[i]));
    while(sum >> 16) sum = (sum >> 16) + (sum & 0xffff);
    return ~sum;
}

/* sender initialization, called once at the very beginning */
void Sender_Init()
{
    sequence_number = 1;
    while (!unsend_pkts.empty()) unsend_pkts.pop();
    unack_pkts.clear();
    fprintf(stdout, "At %.2fs: sender initializing ...\n", GetSimulationTime());
}

/* sender finalization, called once at the very end.
   you may find that you don't need it, in which case you can leave it blank.
   in certain cases, you might want to take this opportunity to release some 
   memory you allocated in Sender_init(). */
void Sender_Final()
{
    fprintf(stdout, "At %.2fs: sender finalizing ...\n", GetSimulationTime());
}

/* event handler, called when a message is passed from the upper layer at the 
   sender */
void Sender_FromUpperLayer(struct message *msg)
{
    int header_size = 2 + 1 + 4;

    /* maximum payload size */
    int maxpayload_size = RDT_PKTSIZE - header_size;

    /* split the message if it is too big */

    /* the cursor always points to the first unsent byte in the message */
    int cursor = 0;

    while (msg->size-cursor > maxpayload_size) {
        /* fill in the packet */
        struct packet* pkt = (struct packet*) malloc (sizeof(struct packet));
        pkt->data[2] = maxpayload_size;
        memcpy(pkt->data+2+1, &sequence_number, sizeof(sequence_number));
        memcpy(pkt->data+header_size, msg->data+cursor, pkt->data[2]);
        short checksum = Sender_CheckSum(pkt);
        memcpy(pkt->data, &checksum, sizeof(checksum));

        /* send it out through the lower layer */
        unack_pkts[sequence_number] = false;
        if (window_left > 0) //window is not filled
        {
            Sender_ToLowerLayer(pkt); 
            if (sliding_window.empty()) // there is no pkt in window, set the timer
                Sender_StartTimer(timeout);
            sliding_window[sequence_number] = pkt;
            window_left--;
        }
        else 
            unsend_pkts.push(pkt);
        sequence_number++;
            
        /* move the cursor */
        cursor += maxpayload_size;
    }

    /* send out the last packet */
    if (msg->size > cursor) {
        /* fill in the packet */
        struct packet* pkt = (struct packet*) malloc (sizeof(struct packet));
        pkt->data[2] = msg->size-cursor;
        memcpy(pkt->data+2+1, &sequence_number, sizeof(sequence_number));
        memcpy(pkt->data+header_size, msg->data+cursor, pkt->data[2]);
        short checksum = Sender_CheckSum(pkt);
        memcpy(pkt->data, &checksum, sizeof(checksum));

        /* send it out through the lower layer */
        unack_pkts[sequence_number] = false;
        if (window_left > 0) //window is not filled
        {
            Sender_ToLowerLayer(pkt);
            if (sliding_window.empty()) // there is no pkt in window, set the timer
                Sender_StartTimer(timeout);
            sliding_window[sequence_number] = pkt;
            window_left--;
        }
        else 
            unsend_pkts.push(pkt);
        sequence_number++;

    }
}

/* event handler, called when a packet is passed from the lower layer at the 
   sender */
void Sender_FromLowerLayer(struct packet *pkt)
{
    short ack_checksum;
    memcpy(&ack_checksum, pkt->data, sizeof(ack_checksum));
    if(ack_checksum != Sender_CheckSum(pkt)) 
        return;
    
    int temp_sequence_number;
    memcpy(&temp_sequence_number, pkt->data + 2, sizeof(temp_sequence_number));
    unack_pkts[temp_sequence_number] = true; // set ack to be true
    
    if (sliding_window.begin()->first == temp_sequence_number) // if it's the first pkt in window, reset the timer
        Sender_StartTimer(timeout);

    std::map<int, struct packet*>::iterator iter= sliding_window.begin();
    while ( iter != sliding_window.end()) // remove acked pkts
    {
        if (unack_pkts[iter->first] == true)
        {
            iter = sliding_window.erase(iter);
            window_left++;
        }
        else
            iter++;
    }

    while (!unsend_pkts.empty() && window_left > 0) // check if front pkt can be sent
    {
        struct packet* front_pkt = (struct packet*) malloc (sizeof(struct packet));
        front_pkt = unsend_pkts.front();  
        memcpy(&temp_sequence_number, front_pkt->data+2+1, sizeof(temp_sequence_number));
        
        Sender_ToLowerLayer(front_pkt);
        unsend_pkts.pop();
        sliding_window[temp_sequence_number] = front_pkt;
        window_left--;
    }

    if (unsend_pkts.empty() && sliding_window.empty())
        Sender_StopTimer();
}

/* event handler, called when the timer expires */
void Sender_Timeout()
{
    std::map<int, struct packet*>::iterator iter= sliding_window.begin();
    Sender_ToLowerLayer(iter->second);

    Sender_StartTimer(timeout);
}