/*
 * FILE: rdt_receiver.cc
 * DESCRIPTION: Reliable data transfer receiver.
 * NOTE: This implementation assumes there is no packet loss, corruption, or 
 *       reordering.  You will need to enhance it to deal with all these 
 *       situations.  In this implementation, the packet format is laid out as 
 *       the following:
 *       
 *       |<-  1 byte  ->|<-             the rest            ->|
 *       | payload size |<-             payload             ->|
 *
 *       The first byte of each packet indicates the size of the payload
 *       (excluding this single-byte header)
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <map>

#include "rdt_struct.h"
#include "rdt_receiver.h"

std::map<int, struct message*> received_msgs;
std::map<int, bool> msg_status; // int = sequence number, false-recieved but unsendToUpper true-sentToUpper
int last_upper = 0;

short Receiver_CheckSum(struct packet* pkt) 
{
    unsigned long sum = 0;
    for(int i = 2; i < RDT_PKTSIZE; i += 2) sum += *(short *)(&(pkt->data[i]));
    while(sum >> 16) sum = (sum >> 16) + (sum & 0xffff);
    return ~sum;
}

/* receiver initialization, called once at the very beginning */
void Receiver_Init()
{
    received_msgs.clear();
    msg_status.clear();
    fprintf(stdout, "At %.2fs: receiver initializing ...\n", GetSimulationTime());
}

/* receiver finalization, called once at the very end.
   you may find that you don't need it, in which case you can leave it blank.
   in certain cases, you might want to use this opportunity to release some 
   memory you allocated in Receiver_init(). */
void Receiver_Final()
{   
    int i = last_upper + 1;
    while (true)
    {
        if ( msg_status.count(i) == 0 )
            break;
        else if ( msg_status[i] == false ) 
        {
            Receiver_ToUpperLayer(received_msgs[i]);
            last_upper = i;
            msg_status[i] = true;
            i++;
        }
    }

    fprintf(stdout, "At %.2fs: receiver finalizing ...\n", GetSimulationTime());
}

/* event handler, called when a packet is passed from the lower layer at the 
   receiver */
void Receiver_FromLowerLayer(struct packet *pkt)
{
    short pkt_checksum;
    memcpy(&pkt_checksum, pkt->data, sizeof(pkt_checksum));
    if(pkt_checksum != Receiver_CheckSum(pkt)) 
        return;

    /* 1-byte header indicating the size of the payload */
    int header_size = 2 + 1 + 4;

    struct packet* ack_pkt = (struct packet*) malloc (sizeof(struct packet));
    int ack_sequence_number;

    /* construct a message and deliver to the upper layer */
    struct message *msg = (struct message*) malloc(sizeof(struct message));
    ASSERT(msg!=NULL);

    msg->size = pkt->data[2];
    memcpy(&ack_sequence_number, pkt->data+2+1, sizeof(ack_sequence_number));

    /* sanity check in case the packet is corrupted */
    if (msg->size<0) msg->size=0;
    if (msg->size>RDT_PKTSIZE-header_size) msg->size=RDT_PKTSIZE-header_size;

    msg->data = (char*) malloc(msg->size);
    ASSERT(msg->data!=NULL);

    memcpy(ack_pkt->data+2, &ack_sequence_number, sizeof(ack_sequence_number));
    short checksum = Receiver_CheckSum(ack_pkt);
    memcpy(ack_pkt->data, &checksum, sizeof(checksum));
    Receiver_ToLowerLayer(ack_pkt);  // send ack

    memcpy(msg->data, pkt->data+header_size, msg->size);
    received_msgs[ack_sequence_number] = msg;
    
    if (msg_status.count(ack_sequence_number) == 0) // if already received, do nothing
        msg_status[ack_sequence_number] = false;
    
    for (int i=last_upper+1; i<=ack_sequence_number; i++) // check if any msg can be sent to upperlayer
    {
        if (msg_status.count(i) == 0) 
            break;
        else if ( msg_status[i] == false && (i == 1 || msg_status[i-1] == true)) //i is received and (i-1 is sent or i = 1)
        {
            Receiver_ToUpperLayer(received_msgs[i]);
            last_upper = i;
            msg_status[i] = true;
        }
    }
}
